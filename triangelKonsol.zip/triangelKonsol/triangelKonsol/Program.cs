using System;
using System.Collections.Generic;
using System.Text;

namespace triangelKonsol
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;

            Console.WriteLine("Ange hur m�nga siffror som ska skrivas ut: ");
            n = Int32.Parse(Console.ReadLine());

            Console.ForegroundColor = ConsoleColor.DarkCyan;

            //outer loop to iterate through all numbers up to the entered value
            for (int i = 1; i <= n; i++)
            {
                //write all numbers up to the current number of the outer loop
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine("");
            }

            //do the opposite looping for descending order
            //outer loop to iterate through all numbers up to the entered value
            for (int i = n -1; i > 0; i--)
            {
                //write all numbers up to the current number of the outer loop
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine("");
            }

            Console.WriteLine("Press any key ...");
            Console.ReadKey();

        }
    }
}
